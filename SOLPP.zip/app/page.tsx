"use client";

import { useState } from "react";
import {
  Connection,
  PublicKey,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";

const TREASURY = "23BGxPV6Q4SXBd51xs5pvWAZ2k3MPGxyPJjHinKc3f5S";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [message, setMessage] = useState("");
  const [selectedSide, setSelectedSide] = useState<"heads" | "tails" | null>(
    null
  );
  const [selectedAmount, setSelectedAmount] = useState(0.01);
  const [flipping, setFlipping] = useState(false);

  const connection = new Connection(
    "https://api.devnet.solana.com",
    "confirmed"
  );

  const flipCoin = async () => {
    if (!selectedSide) return alert("Select Heads or Tails");
    if (!window.solana) return alert("Phantom wallet not found");

    try {
      setLoading(true);
      setFlipping(true);
      setResult("");
      setMessage("");

      const provider = window.solana;
      await provider.connect();

      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: provider.publicKey,
          toPubkey: new PublicKey(TREASURY),
          lamports: selectedAmount * LAMPORTS_PER_SOL,
        })
      );

      transaction.feePayer = provider.publicKey;
      transaction.recentBlockhash = (
        await connection.getLatestBlockhash()
      ).blockhash;

      const signed = await provider.signTransaction(transaction);
      await connection.sendRawTransaction(signed.serialize());

      // 45% win logic
      const win = Math.random() < 0.45;
      const landed = win
        ? selectedSide
        : selectedSide === "heads"
        ? "tails"
        : "heads";

      setTimeout(() => {
        setResult(landed);
        setMessage(
          win
            ? `You WON ${(selectedAmount * 1.98).toFixed(2)} SOL 🎉`
            : "You lost. Try again."
        );
        setFlipping(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      alert("Transaction failed");
      setFlipping(false);
    }

    setLoading(false);
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-black relative overflow-hidden">

      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-black to-blue-900 opacity-60 blur-3xl animate-pulse"></div>

      <div className="relative z-10 w-[420px] p-10 rounded-3xl backdrop-blur-xl bg-white/5 border border-purple-500/30 shadow-[0_0_80px_rgba(168,85,247,0.6)]">

        <h1 className="text-4xl font-extrabold text-center mb-2 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
          SOLANA COIN FLIP
        </h1>

        <p className="text-center text-gray-400 mb-6">
          60% Win Chance • 2% House Edge • Devnet
        </p>

        {/* Coin */}
        <div className="flex justify-center mb-6">
          <div
            className={`w-24 h-24 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 shadow-lg flex items-center justify-center text-black font-bold text-xl transition-transform duration-1000 ${
              flipping ? "rotate-[1080deg]" : ""
            }`}
          >
            {result ? result.toUpperCase() : "?"}
          </div>
        </div>

        {/* Side Selection */}
        <div className="flex gap-4 justify-center mb-6">
          {["heads", "tails"].map((side) => (
            <button
              key={side}
              onClick={() => setSelectedSide(side as any)}
              className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 ${
                selectedSide === side
                  ? "bg-purple-600 scale-110 shadow-lg"
                  : "bg-gray-700 hover:bg-purple-600 hover:scale-105"
              }`}
            >
              {side.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Bet Amount */}
        <div className="flex gap-3 justify-center mb-6">
          {[0.01, 0.1, 0.5].map((amt) => (
            <button
              key={amt}
              onClick={() => setSelectedAmount(amt)}
              className={`px-4 py-2 rounded-lg font-bold transition-all ${
                selectedAmount === amt
                  ? "bg-blue-600 scale-110"
                  : "bg-blue-800 hover:bg-blue-600"
              }`}
            >
              {amt} SOL
            </button>
          ))}
        </div>

        {/* Flip Button */}
        <button
          onClick={flipCoin}
          disabled={loading}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:scale-105 active:scale-95 transition-all font-bold text-lg shadow-lg"
        >
          {loading ? "Processing..." : "FLIP COIN"}
        </button>

        {/* Result */}
        {message && (
          <p
            className={`mt-6 text-center text-lg font-semibold ${
              message.includes("WON")
                ? "text-green-400"
                : "text-red-400"
            }`}
          >
            {message}
          </p>
        )}
      </div>
    </main>
  );
}


